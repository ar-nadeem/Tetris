Noam Mani- 203439450
May Miller- 205661598

Lecturer: Mr. Amir Kirsh
Practitioner: Mr. Amir Kirsh

Group: Thursday 13:15-15:45

Exrcise: 1

