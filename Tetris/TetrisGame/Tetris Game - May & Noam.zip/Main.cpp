#include "TetrisGame.h"

void main() {
	TetrisGame().mainMenu();
	cout << endl << endl << endl << endl << endl << endl;
}