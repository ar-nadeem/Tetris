#include "Jocker.h"

//The function moves the jocker according to the given direction
bool Jocker::move(Keys dir) {

	switch (dir) {
	case LEFT:
		if (isAbleToMove(-1, 0)) {
			printPrevPoint();
			body.move(-1, 0);
			return true;
		}
		break;
	case RIGHT:
		if (isAbleToMove(1, 0)) {
			printPrevPoint();
			body.move(1, 0);
			return true;
		}
		break;
	case DOWN:
		if (isAbleToMove(0, 1)) {
			printPrevPoint();
			body.move(0, 1);
			return true;
		}
		else
			return false;
		break;
	case STOP_JOCKER:
		return false;
		break;
	case DIRECT:
		while (isAbleToMove(0, 1)) {
			printPrevPoint();
			body.move(0, 1);
			score += 2;
		}
		break;
	}
	return true;
}

//The function prints the previous point after the jocker passed it
void Jocker::printPrevPoint() {
	BoardCell temp = board.getBoardCell(body.getY() - INDENTATION, body.getX() - INDENTATION);

	setTextColor((Color)temp.getColor());
	gotoxy(body.getX(), body.getY());
	cout << (char)temp.getSign();
	gotoxy(body.getX(), body.getY());

	setTextColor(color); //Back to the Jocker's color
}