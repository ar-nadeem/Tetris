#pragma once
#include "Shape.h"
#include "Bomb.h"
#include "Jocker.h"

class TetrisGame {
	Board board;
	int score = 0;
	int countShapes = 0;
	bool isJockerInRow = false;
	int speedGame = 200;


public:
	//inline Funstions:
	void updateScore(int num) { score += num; }
	void updateCountShapes() {
		countShapes++;
		gotoxy(14, 4);
		cout << "       ";
		gotoxy(14, 4);
		cout << countShapes;
	}

	//cpp Functions:
	void run();
	//Sub-Functions for run()
	bool checkKeyPressed(Keys key,Color prevColor);
	bool checkGameOver();
	bool updateRow();
	bool isRowFull(int i);
	void deleteRow(int r);
	void mainMenu();
	void updateScoreByRows(int &countRows);
};
