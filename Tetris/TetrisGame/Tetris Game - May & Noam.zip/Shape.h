#pragma once
#include "Board.h"
#include "Keys.h"
#include <time.h>

enum {BODY_SIZE=4};
class Shape {
	Point body[BODY_SIZE][BODY_SIZE];
	int serial;
	ShapeType type;
	Signs sign;
	Board &board;
	bool shouldRotate;
	int score;
	Color color;

public:
	//Constructor:
	Shape(Board &b) :board(b) {};

	//inline Functions:
	int getScore() { return score; }
	Color getColor() { return color; }

	//CPP Functions:
	void createShape(ShapeType type, int serial);
	bool move(Keys dir);
	bool isAbleToMove(int x, int y);
	void makeAmove(int x, int y, bool needRotate = false);
	void printShape(int x, int y);
	void rotate();
	void swapSigns(Point &a, Point &board, Point &c, Point &d);
	bool isLastColEmpty();
	void moveNextCol();
	void rotateBack();
	bool isLastRowEmpty();
	void moveNextRow();
	bool isAbleToRotate();
	void setPointsToBoad();
	void randomColor();
};