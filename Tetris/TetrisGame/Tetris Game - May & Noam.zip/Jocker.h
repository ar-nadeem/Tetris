#pragma once
#include "Board.h"
#include "Keys.h"

class Jocker {
	Point body;
	int serial;
	Board &board;
	int score;
	const Color color = LIGHTGREEN;
	const Signs sign = JOCKER_SIGN;
public:
	//Constructor:
	Jocker(Board &b) : board(b) {}

	//inline Functions:
	void reNewJocker(int _serial) {
		setTextColor(color);
		body = Point(10, 6, sign);
		score = 0;
		setSerial(_serial);
	}

	void setSerial(int _serial) { serial = _serial; }

	void setJockerToBoard() {
		if (board.getSerial(body.getY(), body.getX()) == 0)
			board.set(body, this->serial,this->color);
		else
			printPrevPoint();
	}
	bool isAbleToMove(int x, int y) {
		return (board.getSerial(body.getY() + y, body.getX() + x) != EDGE);
	}

	//cpp Functions:
	bool move(Keys dir);
	void printPrevPoint();
	int getScore() { return score; }
};
