#pragma once
#include "Point.h"
#include "BoardCell.h"

enum Size { ROW = 15, COL = 10 };
enum BOARD { EDGE = -1 };
enum ShapeType { BOMB = 0, JOCKER, LINE, SQUARE };

class Board {
	BoardCell board[ROW + 2][COL + 2];

public:
	//Constructor - cpp
	Board();

	//inline Function:
	void set(Point p, int serial, Color color) {
		int r = p.getY() - INDENTATION;
		int c = p.getX() - INDENTATION;
		getBoardCell(r, c).set(serial, p.getChar(), color);
	};

	int getSerial(int x, int y) {
		return board[x - INDENTATION][y - INDENTATION].getSerial();
	}

	int getSign(int r, int c) {
		return board[r][c].getSign();
	}

	int getSerialByRowCol(int r, int c) {
		return board[r][c].getSerial();
	}

	void swapCellDown(int r, int c) {
		char tempSign;
		int tempSerial;
		BoardCell temp = getBoardCell(r, c);
		//swap the signs only

		board[r][c].set(board[r + 1][c].getSerial(), board[r + 1][c].getSign(), (Color)board[r + 1][c].getColor());
		board[r + 1][c].set(temp.getSerial(), temp.getSign(), (Color)temp.getColor());
		printNewCells(r, c);
	}

	void printNewCells(int r, int c) {
		setTextColor((Color)board[r + 1][c].getColor());
		gotoxy(c + INDENTATION, r + INDENTATION);
		cout << (char)board[r][c].getSign();
		gotoxy(c + INDENTATION, r + INDENTATION + 1);
		cout << (char)board[r + 1][c].getSign();
	}

	BoardCell& getBoardCell(int r, int c) { return board[r][c]; }

	//cpp Functions:
	void findShapeRec(BoardCell &start, BoardCell * arr, int & size);
	void updateBoard();
	void moveDown(BoardCell *arr, int size);
	bool ableToMoveDown(BoardCell arr[], int size);
};