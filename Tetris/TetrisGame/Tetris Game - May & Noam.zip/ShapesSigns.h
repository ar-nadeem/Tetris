#pragma once

enum Signs{ SQUARE_SIGN= '#', LINE_SIGN='#', BOMB_SIGN='@', JOCKER_SIGN='J',
			EMPTY = ' ', EFFECT_BOMB='*',EFFECT_ROW='*', EDGE_SIGN = 176};