#pragma once

#include <conio.h>
#include "Gotoxy.h"
#include "ShapesSigns.h"

class Point {
	int x, y;
	Signs ch;

public:
	//Constructor:
	Point(int x = 1, int y = 1, Signs ch = EMPTY) : x(x), y(y), ch(ch) {}

	//inline Functions:
	void draw(Signs c) {
		gotoxy(x, y);
		cout << (char)c;
		cout.flush();
	}

	void move(int dirX, int dirY) {
		updatePoint(dirX, dirY);
		if (ch != EMPTY)
			draw(ch);
	}

	int getX() { return x; }
	int getY() { return y; }
	Signs getChar() { return ch; }
	void setChar(Signs _ch) { ch = _ch; }
	void updatePoint(int dirX, int dirY) {
		x += dirX;
		y += dirY;
	}
};