#ifndef _GOTOXY_H_
#define _GOTOXY_H_
#include <iostream>
#include <windows.h>
#include <process.h>

using namespace std;

void gotoxy(int, int); // Prototype

#endif