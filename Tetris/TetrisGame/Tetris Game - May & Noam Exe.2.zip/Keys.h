#pragma once

enum Keys { LEFT='j', RIGHT='l', DOWN='k', ROTATE='i', STOP_JOCKER='s', 
				 START_GAME='1', PAUSE='2', FAST='3', SLOW='4', EXIT='9', DIRECT=' '};